import math

FAR_PLANE = 0.15
NEAR_PLANE = 0.1

FOV = math.radians(66)
FOV_COT = 1 / math.tan(FOV / 2)
